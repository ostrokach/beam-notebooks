# Apache Beam Interactive Notebooks

[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/ostrokach/beam-notebooks/master?urlpath=lab)
